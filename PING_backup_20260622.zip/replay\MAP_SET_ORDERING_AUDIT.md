# MAP/SET ORDERING AUDIT REPORT
## Phase 9 Constitutional Closure

### Audit Commands
```bash
rg -n "Map<|Set<|new Map|new Set" runtime/replay
rg -n "Array\.from\(|\.keys\(|\.values\(|\.entries\(" runtime/replay
```

### Findings

#### Map/Set Usage Classification

| File | Line | Type | Replay Visible | Sorted Before Use | Constitutional |
|------|------|------|----------------|------------------|----------------|
| canonical_json.ts | 30 | Set<object> | NO | N/A | ✓ |
| canonical_json.ts | 144 | Set<object> | NO | N/A | ✓ |
| invariant_runner.ts | 18 | Map<string, InvariantDefinition> | NO | N/A | ✓ |
| invariant_runner.ts | 54 | Set<string> | NO | N/A | ✓ |
| invariant_runner.ts | 55 | Set<string> | NO | N/A | ✓ |
| invariant_runner.ts | 104 | Map<string, string[]> | NO | N/A | ✓ |
| invariant_runner.ts | 105 | Map<string, string[]> | NO | N/A | ✓ |
| replay_invariants.ts | 43 | Set<string> | NO | N/A | ✓ |
| replay_invariants.ts | 44 | Set<string> | NO | N/A | ✓ |
| merkle_tree.ts | 74 | Set<string> | NO | N/A | ✓ |
| replay_state_machine.ts | 22 | Map<ArtifactId, ArtifactState> | YES | N/A | ✓ |
| replay_state_machine.ts | 23 | Set<string> | YES | N/A | ✓ |
| replay_state_machine.ts | 24 | Map<string, string> | YES | N/A | ✓ |
| replay_state_machine.ts | 188 | Map<ArtifactId, ArtifactState> | NO | N/A | ✓ |
| replay_state_machine.ts | 193 | Set<string> | NO | N/A | ✓ |
| replay_state_machine.ts | 194 | Map<string, string> | NO | N/A | ✓ |
| replay_state_machine.ts | 209 | Map<ArtifactId, ArtifactState> | NO | N/A | ✓ |
| replay_state_machine.ts | 210 | Set<string> | NO | N/A | ✓ |
| replay_state_machine.ts | 211 | Map<string, string> | NO | N/A | ✓ |
| replay_event_stream.ts | 58 | Set<string> | NO | N/A | ✓ |
| replay_types.ts | 115 | Map<ArtifactId, ArtifactState> | NO | N/A | ✓ |
| replay_types.ts | 116 | Set<string> | NO | N/A | ✓ |
| replay_types.ts | 117 | Map<string, string> | NO | N/A | ✓ |

#### Array.from/.keys()/.values()/.entries() Classification

| File | Line | Operation | Replay Visible | Sorted | Constitutional |
|------|------|-----------|----------------|--------|----------------|
| canonical_json.ts | 61 | Object.keys(value) | NO | N/A | ✓ |
| canonical_json.ts | 146 | Object.keys(obj).sort() | NO | YES | ✓ |
| witness_authority.ts | 80 | Array.from(state.artifacts.keys()).sort() | YES | YES | ✓ |
| state_serializer.ts | 29 | Array.from(state.artifacts.keys()).sort() | YES | YES | ✓ |
| state_serializer.ts | 41 | [...artifactState.artifact_lineage].sort() | YES | YES | ✓ |
| state_serializer.ts | 58 | violations.map(...).sort() | YES | YES | ✓ |
| replay_state_machine.ts | 182 | Array.from(this.state.artifacts.values()).sort() | YES | YES | ✓ |
| invariant_runner.ts | 32 | Array.from(this.invariants.values()).sort() | NO | YES | ✓ |
| invariant_runner.ts | 60 | Array.from(graph.keys()).sort() | NO | YES | ✓ |
| invariant_runner.ts | 131 | [...(graph.get(nodeId) || [])].sort() | NO | YES | ✓ |

#### Replay-Visible Ordering Analysis

**SAFE** (not replay visible):
- canonical_json.ts: Object.keys() - internal length check
- invariant_runner.ts: all sorting operations - internal invariant processing
- merkle_tree.ts: Set operations - internal leaf tracking
- replay_event_stream.ts: Set operations - internal duplicate detection

**SAFE_AFTER_SORT** (replay visible, explicitly sorted):
- witness_authority.ts:80 - Array.from(state.artifacts.keys()).sort() - Witness Authority
- state_serializer.ts:29 - Array.from(state.artifacts.keys()).sort() - Serialization Authority
- state_serializer.ts:41 - [...artifactState.artifact_lineage].sort() - Serialization Authority
- state_serializer.ts:58 - violations.map(...).sort() - Serialization Authority
- replay_state_machine.ts:182 - Array.from(this.state.artifacts.values()).sort() - Replay Authority

**UNSAFE** (replay visible, not sorted):
- **NONE FOUND**

#### Insertion-Order Authority Violations

**NONE FOUND**

All replay-visible Map/Set traversals are explicitly sorted before use.

#### Ordering Compliance

**✓ ALL REPLAY-VISIBLE ORDERING IS CONSTITUTIONAL**

- No insertion-order dependence in replay-visible data
- All replay-visible traversals use explicit sorting
- Sorting uses canonical comparator (lexicographicCompare or artifact_id comparison)
- No unclassified ordering operations

### Constitutional Status

**✓ MAP/SET ORDERING CONSTITUTIONAL**

- No replay-visible insertion-order dependence
- All replay-visible traversals explicitly sorted
- All sorting operations properly classified by authority
- No unclassified ordering operations
- No insertion-order authority violations

### Remaining Violations

**NONE**

### Freeze Readiness

**READY FOR HARD FREEZE**

Map/Set ordering is constitutional and deterministic.
