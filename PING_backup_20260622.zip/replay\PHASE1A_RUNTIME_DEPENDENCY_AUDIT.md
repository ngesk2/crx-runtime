# Phase 1A: Constitutional Runtime Dependency Audit

**Date:** 2026-06-08  
**Status:** CRITICAL VIOLATIONS FOUND  
**Scope:** 7 Constitutional Authorities

---

## Audit Criteria

**Forbidden Dependencies:**
- Date.now()
- new Date()
- Math.random()
- process.env
- process.cwd
- filesystem access
- network access
- locale-dependent operations
- timezone-dependent operations
- unstable serialization
- unordered iteration
- runtime-generated IDs
- Buffer dependency leakage
- Node-only primitives in kernel layer

---

## Authority 1: CanonicalJson

**File:** `runtime/replay/canonical_json.ts`

### VIOLATIONS FOUND

#### Violation 1: Node Buffer Dependency (PATCH 1)
- **Line 169-172:** `toBuffer` method uses `Buffer.from(canonical, 'utf8')`
- **Severity:** CRITICAL
- **Constitutional Rule:** Kernel cannot depend on Node globals
- **Required Patch:** Replace with pure RFC4648 deterministic encoder OR dedicated Base64Authority module

#### Violation 2: Locale-Dependent Unicode Normalization (PATCH 8)
- **Line 138:** `value.normalize('NFC')` 
- **Severity:** CRITICAL
- **Constitutional Rule:** Forbidden platform-default Unicode behavior
- **Required Patch:** Add constitutional normalization authority with NFC normalization, UTF-8 deterministic encoding, surrogate pair validation

### PASSING CHECKS
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access
- ✅ Deterministic property sorting (lexicographicCompare)
- ✅ Deterministic numeric handling (-0 normalization)
- ✅ Circular reference protection

---

## Authority 2: CanonicalHashAuthority

**File:** `runtime/replay/canonical_hash_authority.ts`

### VIOLATIONS FOUND

#### Violation 1: Node Crypto Dependency
- **Line 23:** `import * as crypto from 'crypto'`
- **Line 71:** `crypto.createHash('sha256')`
- **Severity:** CRITICAL
- **Constitutional Rule:** Kernel cannot depend on Node globals
- **Required Patch:** Replace with pure SHA-256 implementation OR dedicated HashAuthority module

#### Violation 2: Node Buffer Dependency (PATCH 1)
- **Line 47:** `Buffer.from(canonical, 'utf8').toString('base64url')`
- **Line 70:** `Buffer.from(bytes, 'base64url')`
- **Severity:** CRITICAL
- **Constitutional Rule:** Kernel cannot depend on Node globals
- **Required Patch:** Replace with pure RFC4648 deterministic encoder OR dedicated Base64Authority module

### PASSING CHECKS
- ✅ Delegates canonicalization to CanonicalJson (sole canonicalization authority)
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access

---

## Authority 3: StateSerializer

**File:** `runtime/replay/state_serializer.ts`

### VIOLATIONS FOUND

#### Violation 1: Indirect Node Buffer Dependency (PATCH 1)
- **Line 45:** `return CanonicalJson.toBuffer(stateObj)`
- **Line 64:** `return CanonicalJson.toBuffer(violationsObj)`
- **Severity:** CRITICAL
- **Constitutional Rule:** Kernel cannot depend on Node globals
- **Root Cause:** Delegates to CanonicalJson.toBuffer which uses Buffer
- **Required Patch:** Fix CanonicalJson.toBuffer first, then update StateSerializer

### PASSING CHECKS
- ✅ Deterministic artifact ID sorting
- ✅ Deterministic lineage sorting
- ✅ Deterministic violation sorting
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access

---

## Authority 4: DeterministicReplayEngine

**File:** `runtime/replay/deterministic_replay_engine.ts`

### VIOLATIONS FOUND

**NONE**

### PASSING CHECKS
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access
- ✅ No Buffer usage
- ✅ No crypto usage
- ✅ Pure functional replay execution
- ✅ Delegates to constitutional authorities correctly

---

## Authority 5: InvariantRunner

**File:** `runtime/replay/invariant_runner.ts`

### VIOLATIONS FOUND

**NONE**

### PASSING CHECKS
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access
- ✅ No Buffer usage
- ✅ No crypto usage
- ✅ Deterministic invariant execution order (sorted by invariant_id)
- ✅ Deterministic graph traversal (sorted nodes, sorted neighbors)
- ✅ DFS cycle detection

---

## Authority 6: WitnessAuthority

**File:** `runtime/replay/witness_authority.ts`

### VIOLATIONS FOUND

#### Violation 1: Node Buffer Dependency (PATCH 1)
- **Line 119:** `Buffer.from(canonicalBytes.bytes, 'base64url')`
- **Line 124:** `Buffer.from(fingerprint.hash.replace(/^sha256:/, ''), 'hex')`
- **Line 129:** `CanonicalJson.toBuffer(lineage)` (indirect Buffer dependency)
- **Line 134:** `Buffer.from(state.state_version, 'utf8')`
- **Line 139:** `Buffer.from('1.0', 'utf8')`
- **Line 144:** `Buffer.from('1.0', 'utf8')`
- **Line 149:** `Buffer.from('1.0', 'utf8')`
- **Line 154:** `Buffer.from('1.0', 'utf8')`
- **Line 159:** `Buffer.from('sha256', 'utf8')`
- **Line 164:** `Buffer.from(state.artifacts.size.toString(), 'utf8')`
- **Line 187:** `Buffer.from(leafCount.toString(), 'utf8')`
- **Line 192:** `Buffer.from(treeHeight.toString(), 'utf8')`
- **Severity:** CRITICAL
- **Constitutional Rule:** Kernel cannot depend on Node globals
- **Required Patch:** Replace with pure RFC4648 deterministic encoder OR dedicated Base64Authority module

### PASSING CHECKS
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access
- ✅ Deterministic artifact iteration ordering
- ✅ Deterministic lineage derivation

---

## Authority 7: ReplayStateMachine

**File:** `runtime/replay/replay_state_machine.ts`

### VIOLATIONS FOUND

**NONE**

### PASSING CHECKS
- ✅ No Date.now() usage
- ✅ No Math.random() usage
- ✅ No process.env usage
- ✅ No filesystem access
- ✅ No network access
- ✅ No Buffer usage
- ✅ No crypto usage
- ✅ Deterministic failure envelopes
- ✅ Duplicate event ID detection
- ✅ Lineage namespace validation

---

## SUMMARY

### Critical Violations by Authority

| Authority | Buffer Violations | Crypto Violations | Unicode Violations | Total |
|-----------|------------------|------------------|-------------------|-------|
| CanonicalJson | 1 | 0 | 1 | 2 |
| CanonicalHashAuthority | 2 | 1 | 0 | 3 |
| StateSerializer | 2 (indirect) | 0 | 0 | 2 |
| DeterministicReplayEngine | 0 | 0 | 0 | 0 |
| InvariantRunner | 0 | 0 | 0 | 0 |
| WitnessAuthority | 12 | 0 | 0 | 12 |
| ReplayStateMachine | 0 | 0 | 0 | 0 |

### Total Violations: 19

### Patch Priority Order

1. **PATCH 1: Remove Node Buffer Authority** (15 violations)
   - Create Base64Authority module with pure RFC4648 implementation
   - Replace all Buffer.from() calls
   - Replace Buffer usage in CanonicalJson.toBuffer
   - Update all dependent modules

2. **PATCH 8: Canonical UTF-8 Normalization** (1 violation)
   - Add constitutional normalization authority
   - Implement NFC normalization
   - Implement UTF-8 deterministic encoding
   - Implement surrogate pair validation
   - Replace value.normalize('NFC')

3. **Crypto Dependency Removal** (1 violation)
   - Create pure SHA-256 implementation OR dedicated HashAuthority module
   - Replace crypto.createHash('sha256')

### Constitutional Freeze Blocker

**STATUS:** BLOCKED

The replay kernel cannot proceed to Layer 1 implementation until:
- All Node Buffer dependencies are removed
- All crypto dependencies are removed
- Unicode normalization is constitutionalized
- All authorities pass Phase 1A audit

---

## Next Steps

1. Implement PATCH 1: Base64Authority module
2. Implement PATCH 8: Constitutional UTF-8 normalization
3. Implement pure SHA-256 implementation
4. Re-run Phase 1A audit
5. Proceed to Phase 1B: Mutation Surface Audit
