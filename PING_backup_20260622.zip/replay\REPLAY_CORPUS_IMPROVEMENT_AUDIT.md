# REPLAY CORPUS IMPROVEMENT AUDIT

## ADR-000X Alignment Assessment

Constitutional freeze requires replay corpus upgrade to witness-centric certification model.

---

## IMPROVEMENT AUDIT #1: REPLAY CORPUS MUST UPGRADE TO WITNESS-CENTRIC CERTIFICATION

### Current Corpus Structure

```
INPUT_STREAM
EXPECTED_CANONICAL_BYTES
EXPECTED_HASH
EXPECTED_LINEAGE
EXPECTED_STATE
EXPECTED_WITNESS_ROOT
```

### Constitutional Issue

Under ADR-000X, `EXPECTED_HASH` is no longer the certification target. It becomes evidence only.

### Required Upgrade

Replace current naming with ADR-aligned naming:

```
INPUT_STREAM
EXPECTED_EVENT_COMMITMENT      (was EXPECTED_HASH)
EXPECTED_DERIVATION_GRAPH      (was EXPECTED_LINEAGE)
EXPECTED_REPLAY_COMMITMENT     (was EXPECTED_WITNESS_ROOT)
EXPECTED_CANONICAL_BYTES       (unchanged)
EXPECTED_STATE                (unchanged)
```

### Rationale

ADR-000X freezes naming:
- `Fingerprint` → `EventStreamCommitment`
- `WitnessRoot` → `ReplayCommitment`
- `LineageGraph` → `DerivationGraph`

Corpus must reflect constitutional naming freeze.

### Classification

**P0** - Corpus naming must align with constitutional freeze.

---

## IMPROVEMENT AUDIT #2: MANDATORY WITNESS EQUALITY CERTIFICATION

### Current Corpus Tests

```
Step 3: Compare actual canonical bytes with EXPECTED_CANONICAL_BYTES
Step 4: Compare actual hash with EXPECTED_HASH
Step 5: Compare actual lineage with EXPECTED_LINEAGE
Step 6: Compare actual state with EXPECTED_STATE
Step 7: Compare actual witness root with EXPECTED_WITNESS_ROOT
```

### Constitutional Issue

ADR-000X introduces:
```
ReplayEquivalent(A, B)
    iff
WitnessRoot(A) == WitnessRoot(B)
```

Current corpus tests individual components but does not test replay equivalence.

### Required Addition

Add replay equivalence certification test:

```typescript
// Replay Equivalence Test
const replayA = engine.replay(eventStream);
const replayB = engine.replay(eventStream);

assert(
  replayA.witness_root === replayB.witness_root,
  "Replay equivalence violation: same input must produce same witness root"
);
```

### Rationale

ADR-000X defines replay equivalence exclusively by witness equality. Corpus must verify this constitutional law.

### Classification

**P0** - Constitutional equivalence test is mandatory.

---

## IMPROVEMENT AUDIT #3: CERTIFICATION INVARIANT NOT YET REPRESENTED

### ADR-000X Invariant

```
WitnessEquality => FingerprintEquality
```

Because witness root commits to fingerprint, equal witnesses must imply equal fingerprints.

### Current Corpus Status

**MISSING** - No certification invariant test exists.

### Required Addition

Add `CERTIFICATION_INVARIANTS.json`:

```json
{
  "witness_implies_fingerprint": true,
  "witness_subsumes_fingerprint": true,
  "fingerprint_subordinate_to_witness": true
}
```

Add verifier:

```typescript
// Certification Invariant Test
if (witnessA.witness_root === witnessB.witness_root) {
  assert(
    fingerprintA.hash === fingerprintB.hash,
    "Certification invariant violation: witness equality must imply fingerprint equality"
  );
}
```

### Rationale

ADR-000X makes this invariant constitutionally mandatory. Violation indicates witness corruption, incomplete commitment scope, or constitutional replay divergence.

### Classification

**P0** - Constitutional invariant test is mandatory.

---

## IMPROVEMENT AUDIT #4: WITNESS LAW VERSION MISSING

### ADR-000X Requirement

Witness root MUST commit to:
- witness law versioning

### Current Witness Leaves

```
schema_version
replay_version
policy_version
canonicalization_version
hash_version
```

### Missing Leaf

```
witness_law_version
```

### Required Addition

Add witness leaf to `witness_authority.ts`:

```typescript
{
  leaf_id: toWitnessLeafId('witness_law_version'),
  leaf_bytes: Buffer.from(this.witnessLawVersion, 'utf8'),
  leaf_hash: ''
}
```

Add corpus artifact:
```
EXPECTED_WITNESS_LAW_VERSION.json
```

Even if implementation remains `1.0`, corpus must reserve this field to prevent future replay-law drift.

### Rationale

ADR-000X states witness commits to witness law versioning. Missing this leaf allows undetected replay-law drift.

### Classification

**P1** - High priority (prevents future drift).

---

## IMPROVEMENT AUDIT #5: parent_event_ids AMBIGUITY CONFIRMED

### Forensic Finding

Field name: `parent_event_ids`
Type: `ArtifactId[]`
Comment: "lineage uses artifact IDs only"
Runtime: Supports both `evt-*` and artifact IDs with conversion semantics

### ADR-000X Freeze

```
parent_event_ids → parent_object_refs
```

### Constitutional Issue

This is an active semantic fracture:
- Field name says "event"
- Type says "artifact"
- Runtime accepts both with conversion
- ADR freezes to "object_refs" to clarify this is not event lineage

### Required Action

Rename in corpus and runtime:
```
parent_event_ids → parent_object_refs
```

Update all references:
- `replay_types.ts`
- `canonical_event_envelope.ts`
- `replay_state_machine.ts`
- `witness_authority.ts`
- Corpus JSON files

### Rationale

ADR-000X clarifies: `LineageGraph != Event Graph`. Under constitutional model, lineage is derivation evidence, not event graph. Current naming is P0 constitutional debt.

### Classification

**P0** - Constitutional naming debt (not runtime failure, but architectural ambiguity).

---

## IMPROVEMENT AUDIT #6: WITNESS LEAF INVENTORY IS MISSING AUTHORITY CLASSIFICATION

### Current Witness Leaves

```
canonical_bytes
fingerprint
lineage
state_version
schema_version
replay_version
policy_version
canonicalization_version
hash_version
artifact_count
state_contents
violations_canonical
leaf_count
tree_height
```

### Constitutional Issue

Leaves are structurally correct but lack constitutional classification.

### Required Addition

Add witness specification document with authority classification:

```typescript
enum WitnessLeafAuthority {
  INPUT_COMMITMENT,      // canonical_bytes, fingerprint
  DERIVATION_EVIDENCE,   // lineage
  EXECUTION_STATE,       // state_contents, state_version
  OUTCOME_EVIDENCE,      // violations_canonical
  LAW_METADATA,          // schema_version, replay_version, etc.
  TOPOLOGY_METADATA      // leaf_count, tree_height
}

const LEAF_AUTHORITY_MAP: Record<string, WitnessLeafAuthority> = {
  'canonical_bytes': WitnessLeafAuthority.INPUT_COMMITMENT,
  'fingerprint': WitnessLeafAuthority.INPUT_COMMITMENT,
  'lineage': WitnessLeafAuthority.DERIVATION_EVIDENCE,
  'state_contents': WitnessLeafAuthority.EXECUTION_STATE,
  'state_version': WitnessLeafAuthority.EXECUTION_STATE,
  'violations_canonical': WitnessLeafAuthority.OUTCOME_EVIDENCE,
  'schema_version': WitnessLeafAuthority.LAW_METADATA,
  'replay_version': WitnessLeafAuthority.LAW_METADATA,
  'policy_version': WitnessLeafAuthority.LAW_METADATA,
  'canonicalization_version': WitnessLeafAuthority.LAW_METADATA,
  'hash_version': WitnessLeafAuthority.LAW_METADATA,
  'witness_law_version': WitnessLeafAuthority.LAW_METADATA,
  'artifact_count': WitnessLeafAuthority.EXECUTION_STATE,
  'leaf_count': WitnessLeafAuthority.TOPOLOGY_METADATA,
  'tree_height': WitnessLeafAuthority.TOPOLOGY_METADATA
};
```

### Rationale

Prevents future authority drift. Constitutional classification makes explicit which leaves are identity-defining vs evidentiary vs metadata.

### Classification

**P1** - High priority (prevents architectural drift).

---

## IMPROVEMENT AUDIT #7: REPLAY CORPUS SHOULD VERIFY AUTHORITY HIERARCHY

### ADR-000X Authority Chain

```
Event Stream
    ↓
Fingerprint
    ↓
Replay Execution
    ↓
Lineage + State + Violations
    ↓
Witness Root
    ↓
Replay Identity
```

### Current Corpus Tests

Corpus verifies individual values (canonical bytes, hash, lineage, state, witness) but does not verify authority ordering.

### Required Addition

Add authority hierarchy certification test:

```typescript
// Authority Hierarchy Test
// Test 1: Fingerprint mutation must change witness root
const originalReplay = engine.replay(eventStream);
const originalFingerprint = originalReplay.fingerprint;
const originalWitness = originalReplay.witness_root;

// Mutate event stream
const mutatedEventStream = eventStream.appendEvent(modifiedEvent);
const mutatedReplay = engine.replay(mutatedEventStream);
const mutatedFingerprint = mutatedReplay.fingerprint;
const mutatedWitness = mutatedReplay.witness_root;

assert(
  mutatedFingerprint.hash !== originalFingerprint.hash,
  "Fingerprint must change when event stream changes"
);

assert(
  mutatedWitness.witness_root !== originalWitness.witness_root,
  "Witness root must change when fingerprint changes"
);

// Test 2: Witness root subsumes fingerprint authority
// (This is already verified by witness leaf #2 containing fingerprint)
```

### Rationale

Verifies constitutional authority hierarchy: Fingerprint participates in Replay Commitment. If fingerprint changes, witness root must change.

### Classification

**P1** - High priority (verifies constitutional authority chain).

---

## IMPROVEMENT AUDIT #8: IDENTITY DEPENDENCY GRAPH IS NOW RESOLVED

### Previous Forensic Result

```
No single replay identity authority.
```

### ADR-000X Resolution

```
ReplayIdentity = WitnessRoot
```

### Resolved Dependency Graph

```
Event Stream
    ↓
EventStreamCommitment (was Fingerprint)
    ↓
Replay Execution
    ↓
DerivationGraph (was LineageGraph)
    ↓
State
    ↓
Violations
    ↓
ReplayCommitment (was WitnessRoot)
    ↓
ReplayIdentity
```

### Constitutional Significance

This is the first fully constitutional authority chain in the corpus. Previous forensic audit identified authority fracture; ADR-000X resolves it by establishing witness root as sole constitutional replay identity.

### Classification

**RESOLVED** - ADR-000X closes the largest authority ambiguity in the architecture.

---

## IMPROVEMENT AUDIT #9: REPLAY RESULT SCHEMA FREEZE

### ADR-000X Schema

```typescript
type ReplayResult = {
  replay_identity: WitnessRoot;        // was witness_root
  event_commitment: Fingerprint;       // was fingerprint
  derivation_graph: LineageGraph;      // was lineage_graph
  replay_state: ReplayState;           // unchanged
  violations: InvariantViolation[];    // unchanged
};
```

### Current Corpus Artifacts

Corpus artifacts still reflect pre-freeze naming:
- `fingerprint`
- `witness_root`
- `lineage_graph`

### Required Action

Update corpus artifacts to mirror ADR schema:
- `fingerprint` → `event_commitment`
- `witness_root` → `replay_identity`
- `lineage_graph` → `derivation_graph`

Update `replay_types.ts`:
```typescript
export interface ReplayResult {
  replay_identity: WitnessRoot;        // NEW: explicit identity field
  event_commitment: Fingerprint;       // RENAME: was fingerprint
  derivation_graph: LineageGraph;      // RENAME: was lineage_graph
  replay_state: ReplayState;
  violations: InvariantViolation[];
  state_version: string;
  artifact_count: number;
  canonical_bytes: CanonicalBytes;     // KEEP: for backward compatibility
}
```

### Rationale

ADR-000X freezes schema. Corpus must mirror constitutional schema to eliminate authority ambiguity.

### Classification

**P0** - Schema must align with constitutional freeze.

---

## IMPROVEMENT AUDIT #10: CONSTITUTIONAL READINESS ASSESSMENT

### Complete

- Event sourcing
- Replay state machine
- Canonicalization
- Fingerprint authority
- Lineage derivation
- Witness generation
- Replay corpus concept
- Identity freeze (ADR-000X)
- Authority hierarchy (ADR-000X)

### Partially Complete

- Witness law versioning (missing from witness leaves)
- Certification invariants (not yet in corpus)
- Replay equivalence certification (not yet in corpus)
- Authority-classified witness leaves (not documented)
- Corpus authority tests (not implemented)

### Not Yet Visible

- Replay commitment proofs
- Cross-host witness certification
- Witness inclusion proofs
- Portable verifier package
- Replay commitment certificates

### Updated Constitutional Assessment

**Previous forensic conclusion**: No single replay identity authority.

**After ADR-000X**: Constitutional model clearly states:
```
ReplayIdentity = ReplayCommitment = WitnessRoot
```

This closes the largest authority ambiguity in the architecture.

### Next Constitutional Milestone

The next constitutional milestone is not additional runtime functionality.

It is: **Replay Commitment Certification**

Where the replay corpus proves:
```
same replay → same witness
same witness → same commitment
same commitment → same replay identity
```

### Classification

**CONSTITUTIONAL ROADMAP** - ADR-000X resolves authority ambiguity; next milestone is certification infrastructure.

---

## SUMMARY OF REQUIRED ACTIONS

### P0 (Mandatory)

1. Rename corpus artifacts to match ADR naming freeze
2. Add replay equivalence certification test
3. Add certification invariant test (witness_implies_fingerprint)
4. Rename parent_event_ids → parent_object_refs
5. Update ReplayResult schema to match ADR freeze

### P1 (High Priority)

6. Add witness_law_version leaf
7. Add witness leaf authority classification
8. Add authority hierarchy certification test

### Constitutional Significance

ADR-000X resolves the authority fracture identified in forensic audits. The replay corpus must now upgrade to witness-centric certification to align with constitutional freeze.

**Constitutional Principle**: System verifies "What constitutional replay result was witnessed?" not merely "What bytes entered the system?"
